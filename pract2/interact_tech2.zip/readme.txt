Project done by:

Bastiaan Weijers - 3256669
B.Weijers@students.uu.nl

Colin Smits - 4075390
C.Smits@uu.nl


Link to the film:
http://youtu.be/ye8yR4tcteo

(also incorporated in paper)

To run:

- Open CMD in folder
- execute bodyMotion.py

(When issues occur, please send a message to the mailadresses above)